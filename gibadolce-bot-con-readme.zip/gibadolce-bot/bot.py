
import os
import time
import requests
from pybit.unified_trading import HTTP
from telegram import Bot

# Legge le variabili d'ambiente
BYBIT_API_KEY = os.getenv("BYBIT_API_KEY")
BYBIT_API_SECRET = os.getenv("BYBIT_API_SECRET")
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
CHAT_ID = os.getenv("CHAT_ID")

# Connessione a Bybit
session = HTTP(
    api_key=BYBIT_API_KEY,
    api_secret=BYBIT_API_SECRET
)

# Connessione a Telegram
bot = Bot(token=TELEGRAM_TOKEN)

def send_telegram_message(message):
    bot.send_message(chat_id=CHAT_ID, text=message)

# Funzione semplice di esempio (verifica saldo)
def check_balance():
    balance = session.get_wallet_balance(accountType="UNIFIED")
    usdt = balance['result']['list'][0]['totalEquity']
    return usdt

# Avvio del bot
if __name__ == "__main__":
    send_telegram_message("Bot avviato con successo!")

    while True:
        try:
            saldo = check_balance()
            send_telegram_message(f"Saldo attuale: {saldo} USDT")
            time.sleep(3600)  # ogni ora
        except Exception as e:
            send_telegram_message(f"Errore: {e}")
            time.sleep(60)
