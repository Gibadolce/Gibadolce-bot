
# Gibadolce Scalping Bot

Bot automatico di scalping per crypto connesso a Bybit e Telegram.

## Funzionalità
- Connessione API con Bybit (live)
- Invia notifiche su Telegram
- Monitora il saldo e fa trading automatico (da estendere)
- Capitale minimo: $10
- Obiettivo giornaliero: $50 (se le condizioni di mercato lo permettono)

## Come funziona
Il bot si connette a Bybit, legge il saldo, e invia aggiornamenti su Telegram ogni ora.

## Setup
1. Carica il bot su [Render](https://render.com)
2. Imposta queste variabili d'ambiente:
   - `BYBIT_API_KEY`
   - `BYBIT_API_SECRET`
   - `TELEGRAM_TOKEN`
   - `CHAT_ID`
3. Comando di compilazione:
   ```
   pip install -r requirements.txt
   ```
4. Comando di avvio:
   ```
   python bot.py
   ```

## Autore
Gibadolce Bot - Creato con amore e ambizione.
