# Gibadolce Bot

Bot di scalping automatico per crypto e forex, pensato per operare su Bybit tramite API e ricevere notifiche su Telegram.

## Funzionalità
- Scalping crypto automatico su tutte le monete disponibili
- Capitale minimo: $10
- Integrazione con Telegram
- Obiettivo: $50/giorno quando possibile

## Installazione
1. Clona il repo:
   ```
   git clone https://github.com/Gibadolce/Gibadolce-bot
   ```
2. Installa le dipendenze:
   ```
   pip install -r requirements.txt
   ```

## Deploy su Render
- Il file `requirements.txt` è già pronto.
- Usa `runtime.txt` per specificare la versione di Python.

## Contatto
Telegram: [Inserisci qui il tuo handle]
