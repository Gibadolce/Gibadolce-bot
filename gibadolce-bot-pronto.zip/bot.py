import os
import time
from pybit.unified_trading import HTTP
from telegram import Bot

# Variabili d'ambiente
BYBIT_API_KEY = os.getenv("BYBIT_API_KEY")
BYBIT_API_SECRET = os.getenv("BYBIT_API_SECRET")
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

# Telegram bot
telegram_bot = Bot(token=TELEGRAM_TOKEN)

# Inizializza la sessione con Bybit
session = HTTP(
    api_key=BYBIT_API_KEY,
    api_secret=BYBIT_API_SECRET
)

def send_telegram(message):
    telegram_bot.send_message(chat_id=TELEGRAM_CHAT_ID, text=message)

def get_balance():
    balance = session.get_wallet_balance(accountType="UNIFIED")
    usdt_balance = balance["result"]["list"][0]["totalEquity"]
    return float(usdt_balance)

def main():
    send_telegram("Gibadolce Bot avviato!")
    while True:
        try:
            balance = get_balance()
            if balance < 10:
                send_telegram(f"Saldo troppo basso: ${balance:.2f}")
            else:
                # Esegui qui la logica di scalping
                send_telegram(f"Saldo OK: ${balance:.2f}")
            time.sleep(60)
        except Exception as e:
            send_telegram(f"Errore: {e}")
            time.sleep(60)

if __name__ == "__main__":
    main()