# Gibadolce Bot

Un bot di scalping automatizzato per crypto, collegato a Bybit e Telegram.

## Funzionalità
- Controlla il saldo Bybit
- Invia notifiche su Telegram
- Esegue operazioni di scalping (da integrare)

## Requisiti

Inserisci le seguenti variabili d'ambiente su Render:
- `BYBIT_API_KEY`
- `BYBIT_API_SECRET`
- `TELEGRAM_TOKEN`
- `TELEGRAM_CHAT_ID`

## Avvio su Render
- Comando build: `pip install -r requirements.txt`
- Comando di avvio: `python bot.py`